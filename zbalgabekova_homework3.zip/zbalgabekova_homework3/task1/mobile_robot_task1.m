%Provide angular velocity as input (I provided 2 in the video)
function mobile_robot_task1(angul_vel)
    path = [1.25 1.75; 3 4; 3.75 7.5; 10.75 9.75];
    path(:, :, 2) = [1 2.5; 3 4; 3.75 7.5; 10.75 9.75];
    path(:, :, 3) = [0.5 6; 3 4; 3.75 7.5; 10.75 9.75];
    
    for i = 1:3
        %Define robot's path
        path1 = path(:, :, i);    
        start_pos = path1(1, :);
        target_pos = path1(end, :);
        init_orient = 0;
        current_pose = [start_pos init_orient]';
        target_radius = 0.1;
        dist_to_target = norm(start_pos - target_pos);

        %Define controller
        robot = differentialDriveKinematics("TrackWidth", 1, "VehicleInputs", "VehicleSpeedHeadingRate");
        controller = controllerPurePursuit;
        controller.Waypoints = path1;
        controller.DesiredLinearVelocity = 1;
        controller.MaxAngularVelocity = angul_vel;
        controller.LookaheadDistance = 0.4;

        %Plot visualization
        figure

        sample_time = 0.1;
        viz_rate = rateControl(1/sample_time);
        frame_size = robot.TrackWidth/0.8;

        while(dist_to_target > target_radius)
            % Calculate controller outputs (inputs to the robot)
            [vel, angvel] = controller(current_pose);

            %Compute robot's velocity
            vel_robot = derivative(robot, current_pose, [vel angvel]);

            %Update current pose
            current_pose = current_pose + vel_robot*sample_time; 

            %Recompute the distance to the target position
            dist_to_target = norm(current_pose(1:2) - target_pos(:));

            %Update the plot
            hold off

            % Plot path each instance 
            plot(path1(:, 1), path1(:, 2),"k--d")

            %Plot obstacles each instance
            hold on
            p = nsidedpoly(1000, 'Center', [4 9], 'Radius', 0.5);
            plot(p, 'FaceColor', 'r')
            axis equal

            p1 = nsidedpoly(1000, 'Center', [4 3], 'Radius', 0.5);
            plot(p1, 'FaceColor', 'r')
            axis equal

            p2 = nsidedpoly(1000, 'Center', [8 6], 'Radius', 0.5);
            plot(p2, 'FaceColor', 'r')
            axis equal

            p3 = nsidedpoly(1000, 'Center', [10 2], 'Radius', 0.5);
            plot(p3, 'FaceColor', 'r')
            axis equal

            %Emphasize target position each instance
            p4 = nsidedpoly(1000, 'Center', [10.75 9.75], 'Radius', 0.3);
            plot(p4, 'FaceColor', 'g')
            axis equal

            hold all

            %Plot robot's path as a set of transforms
            plotTrVec = [current_pose(1:2); 0];
            plotRot = axang2quat([0 0 1 current_pose(3)]);
            plotTransforms(plotTrVec', plotRot, "MeshFilePath", "groundvehicle.stl", "Parent", gca, "View","2D", "FrameSize", frame_size);
            light;
            xlim([0 12])
            ylim([0 12])
            xlabel('X')
            ylabel('Y')
            title(['Mobile Robot 2D Visualization from initial position  ', num2str(i)])

            waitfor(viz_rate);
        end
    end
end