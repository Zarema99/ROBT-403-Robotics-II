%Provide x and y coordinates of initial position
%I provided (1.5, 1.5), (1, 1), and (1.25, 1.75) in the video
function mobile_robot_task2(x, y)
        l = 2;    %distance between wheels
        r = 1;    %radius of a wheel
        %Initial position
        x_init = x;
        y_init = y;
        theta = 0;
        %Target coordinates
        x_t = 10;
        y_t = 10;
        %Weight matrix
        W = [0 0.5 0 0.5; 0.5 0 0.5 0];
        sample_time = 0.1;
        viz_rate = rateControl(1/sample_time);
        dist_to_target = norm([x_t; y_t] - [x; y]);
        target_radius = 1;
        robot = differentialDriveKinematics("TrackWidth", 1, "VehicleInputs", "VehicleSpeedHeadingRate");
        frame_size = robot.TrackWidth/0.8;
        figure
        
        while(dist_to_target > target_radius)
            %signals
            LL = 1/norm([x_t; y_t] - [x - 1; y + 1]);
            LR = 1/norm([x_t; y_t] - [x + 1; y + 1]);
            CL1 = (x - 1) - 0.5;
            CR1 = (x + 1) - 0.5;
            M = [LL; CL1; CR1; LR];
            matrix = W*M + [0.2; 0.2];
            %velocities
            v_l = r*matrix(1);
            v_r = r*matrix(2);
            %Update current pose
            x = x + (v_r + v_l)/2*sample_time;
            y = y + (v_r + v_l)/2*sample_time;
            theta = theta + 1/l*(v_r - v_l)*sample_time;
            x = x + 0.5*(v_r + v_l)*cos(theta)*sample_time;
            y = y + 0.5*(v_r + v_l)*sin(theta)*sample_time;
            %Recompute the distance to the target position
            dist_to_target = norm([x_t; y_t] - [x; y]);
            
            hold off
            %Plot obstacles each instance
            p = nsidedpoly(1000, 'Center', [4 8], 'Radius', 0.5);
            plot(p, 'FaceColor', 'b')
            axis equal

            hold on
            p1 = nsidedpoly(1000, 'Center', [2 4], 'Radius', 0.5);
            plot(p1, 'FaceColor', 'b')
            axis equal

            p2 = nsidedpoly(1000, 'Center', [8 5.5], 'Radius', 0.5);
            plot(p2, 'FaceColor', 'b')
            axis equal

            p3 = nsidedpoly(1000, 'Center', [10 2], 'Radius', 0.5);
            plot(p3, 'FaceColor', 'b')
            axis equal

            %Emphasize target position each instance
            p4 = nsidedpoly(1000, 'Center', [10 10], 'Radius', 1);
            plot(p4, 'FaceColor', 'y')
            axis equal

            hold all

            plotTrVec = [[x; y]; 0];
            plotRot = axang2quat([0 0 1 theta]);
            plotTransforms(plotTrVec', plotRot, "MeshFilePath", "groundvehicle.stl", "Parent", gca, "View","2D", "FrameSize", frame_size);
            light;
            xlim([0 12])
            ylim([0 12])
            xlabel('X')
            ylabel('Y')
            title(['Mobile Robot 2D Visualization from initial position  [', num2str(x_init), ',' ,num2str(y_init), ']'])
            waitfor(viz_rate);
        end
end
