%%
%Exercise 2

%Given
theta_0 = 20;
theta_f = 90;
tf = 3;

%Sampling time
Ts = 0.01;

for i = 1:2
%Parameters
a0 = theta_0;
a1 = 0;
a2 = 3/tf^2*(theta_f - theta_0);
a3 = -2/tf^3*(theta_f - theta_0);

%Time interval
t = 0:Ts:tf;

%position
theta = a0 + a1*t + a2*t.^2 + a3*t.^3;

%velocity - first derivative of position
theta_dot = a1 + 2*a2*t + 3*a3*t.^2;

%acceleration - second derivative of position
theta_dot_dot = 2*a2 + 6*a3*t;

figure
subplot(3, 1, 1)
plot(t, theta)
title(['Position for ', num2str(tf), 's'])
xlabel('Time (s)')
ylabel('Position (Degrees)')

subplot(3, 1, 2)
plot(t, theta_dot)
title(['Velocity for ', num2str(tf), 's'])
xlabel('Time (s)')
ylabel('Velocity (Deg/s)')

subplot(3, 1, 3)
plot(t, theta_dot_dot)
title(['Acceleration for ', num2str(tf), 's'])
xlabel('Time (s)')
ylabel('Acceleration (Deg/s^2)')

tf = 5;
end

%%
%Exercise 3

%Given
theta_0 = -15;
theta_f = 45;
tf = 10;
theta_dot_dot = 3;

%Sampling time
Ts = 0.01;

for i = 1:2
tb = tf/2 - sqrt(theta_dot_dot^2*tf^2 - 4*theta_dot_dot*(theta_f - theta_0))/(2*theta_dot_dot);

%Parameters
a4 = theta_dot_dot*tb;
a0 = theta_0;
a1 = 0;
a6 = a4;
a2 = a4/(2*tb);
a7 = -a6/(2*tb);
a5 = theta_f - a6*tb - a7*tb^2;
a3 = a0 +a1*tb + a2*tb^2;

%Time interval for blends(reset)
t = 0:Ts:tb;
%Time interval for linear segment(reset)
t_lin = 0:Ts:(tf - 2*tb);

%First parabolic blend
theta1 = a0 + a1*t + a2*t.^2;
%Linear segment
theta2 = a3 + a4*t_lin;
%Second parabolic blend
theta3 = a5 + a6*t + a7*t.^2;

%Time interval for linear segment
t2 = tb:Ts:(tf - tb);
%Time interval for second parabolic blend
t3 = (tf - tb):Ts:tf;

figure
plot(t, theta1)
hold on
plot(t2, theta2)
plot(t3, theta3)
title(['Trajectories for ', num2str(theta_dot_dot), ' Deg/s^2'])
xlabel('Time (s)')
ylabel('Position (Degrees)')
hold off

theta_dot_dot = 6;
end



%%
%Exercise 4

%Given
theta_0 = 0;
theta_v = 30;
theta_f = 80;
tf = 2;

%Sampling time
Ts = 0.01;

%Parameters
a10 = theta_0;
a11 = 0;
a12 = (12*theta_v - 3*theta_f - 9*theta_0)/(4*tf^2);
a13 = (-8*theta_v + 3*theta_f + 5*theta_0)/(4*tf^3);

a20 = theta_v;
a21 = (3*theta_f - 3*theta_0)/(4*tf);
a22 = (-12*theta_v + 6*theta_f + 6*theta_0)/(4*tf^2);
a23 = (8*theta_v - 5*theta_f - 3*theta_0)/(4*tf^3);

%Time interval of first cubic polynomial and for reset
t = 0:Ts:tf;

%Time interval of second cubic polynomial
t2 = tf:Ts:2*tf;

%Position
theta1 = a10 + a11*t + a12*t.^2 + a13*t.^3;
theta2 = a20 + a21*t + a22*t.^2 + a23*t.^3;

%Velocity - first derivative of position
theta1_dot = a11 + 2*a12*t + 3*a13*t.^2;
theta2_dot = a21 + 2*a22*t + 3*a23*t.^2;

%Acceleration - second derivative of position
theta1_dot_dot = 2*a12 + 6*a13*t;
theta2_dot_dot = 2*a22 + 6*a23*t;

figure
subplot(3, 1, 1)
plot(t, theta1)
hold on
plot(t2, theta2)
hold off
title('Position')
xlabel('Time (s)')
ylabel('Position (Degrees)')

subplot(3, 1, 2)
plot(t, theta1_dot)
hold on
plot(t2, theta2_dot)
hold off
title('Velocity')
xlabel('Time (s)')
ylabel('Velocity (Deg/s)')

subplot(3, 1, 3)
plot(t, theta1_dot_dot)
hold on
plot(t2, theta2_dot_dot)
hold off
title('Acceleration')
xlabel('Time (s)')
ylabel('Acceleration (Deg/s^2)')




